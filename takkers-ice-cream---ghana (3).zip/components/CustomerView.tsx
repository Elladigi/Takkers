
import React, { useState, useEffect } from 'react';
import { Location, Order, UNIT_PRICE, BULK_UNIT_PRICE, VENDOR_PHONE, MIN_BULK_QUANTITY, OrderType, Flavor, BRAND_NAME, BRAND_LOGO_URL } from '../types';

interface Props {
  onOrderCreated: (order: Order) => void;
  isOnline: boolean;
  orders: Order[];
  savedPhone: string;
  savedName: string;
  onLogout: () => void;
}

const FLAVORS: { name: Flavor; emoji: string; color: string }[] = [
  { name: 'Vanilla', emoji: '🍦', color: 'bg-orange-50' },
  { name: 'Chocolate', emoji: '🍫', color: 'bg-amber-900' },
  { name: 'Strawberry', emoji: '🍓', color: 'bg-rose-400' },
  { name: 'Coconut', emoji: '🥥', color: 'bg-slate-200' },
];

const CustomerView: React.FC<Props> = ({ onOrderCreated, isOnline, orders, savedPhone, savedName, onLogout }) => {
  const [orderType, setOrderType] = useState<OrderType>('regular');
  const [flavor, setFlavor] = useState<Flavor>('Vanilla');
  const [quantity, setQuantity] = useState(1);
  const [phone, setPhone] = useState(savedPhone);
  const [landmark, setLandmark] = useState('');
  const [location, setLocation] = useState<Location | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'locating' | 'requesting' | 'success'>('idle');
  const [forceSmsMode, setForceSmsMode] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Fix: Allow intensity to be a number or a number array to support complex vibration patterns
  const hapticFeedback = (intensity: number | number[] = 10) => {
    if ('vibrate' in navigator) navigator.vibrate(intensity);
  };

  useEffect(() => {
    setStatus('locating');
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          setStatus('idle');
        },
        (err) => {
          console.error("Location error", err);
          setStatus('idle');
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }
  }, []);

  useEffect(() => {
    if (orderType === 'bulk' && quantity < MIN_BULK_QUANTITY) {
      setQuantity(MIN_BULK_QUANTITY);
    }
  }, [orderType]);

  const currentPrice = orderType === 'bulk' ? BULK_UNIT_PRICE : UNIT_PRICE;
  const isUsingSms = !isOnline || forceSmsMode;

  const handleRequest = () => {
    hapticFeedback(20);
    if (!phone || phone.length < 9) {
      alert("📞 Please enter a valid phone number!");
      return;
    }
    if (!location) {
      alert("⚠️ GPS Location required for delivery!");
      return;
    }
    if (!landmark.trim()) {
      alert("📍 Please add a landmark to help the delivery driver!");
      return;
    }

    const min = orderType === 'bulk' ? MIN_BULK_QUANTITY : 1;
    const finalQty = Math.max(min, quantity);

    setLoading(true);
    setStatus('requesting');

    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 6).toUpperCase(),
      quantity: finalQty,
      price: finalQty * currentPrice,
      flavor,
      location: { ...location, landmark: landmark.trim() },
      timestamp: Date.now(),
      status: 'pending',
      customerPhone: phone,
      customerName: savedName,
      isOffline: isUsingSms,
      orderType
    };

    setTimeout(() => {
      hapticFeedback([50, 30, 50]); // Triple pulse on success
      if (isUsingSms) {
        const mapsUrl = `https://www.google.com/maps?q=${location.lat},${location.lng}`;
        const message = `${BRAND_NAME.toUpperCase()} ORDER\n------------------\nBY: ${savedName}\nID: #${newOrder.id}\nFLAVOR: ${flavor}\nQTY: ${finalQty}\nLANDMARK: ${landmark}\nTOTAL: GHS ${(finalQty * currentPrice).toFixed(2)}\nPHONE: ${phone}\nMAP: ${mapsUrl}`;
        window.location.href = `sms:${VENDOR_PHONE}?body=${encodeURIComponent(message)}`;
      }
      onOrderCreated(newOrder);
      setLoading(false);
      setStatus('success');
      setTimeout(() => setStatus('idle'), 5000);
    }, 1000);
  };

  const adjustQty = (delta: number) => {
    hapticFeedback(5);
    setQuantity(prev => Math.max(orderType === 'bulk' ? MIN_BULK_QUANTITY : 1, prev + delta));
  };

  if (showHistory) {
    return (
      <div className="p-6 h-full flex flex-col bg-white overflow-y-auto no-scrollbar pt-safe">
        <div className="pt-10 flex justify-between items-center mb-6">
          <h2 className="text-2xl font-black text-slate-900">Your <span className="text-[#e31b23]">History</span></h2>
          <button 
            onClick={() => { hapticFeedback(5); setShowHistory(false); }}
            className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-900 font-black shadow-sm active:scale-90 transition-all"
          >✕</button>
        </div>
        <div className="space-y-4 pb-20">
          {orders.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-3xl border border-slate-100">
              <p className="text-slate-400 font-black text-[10px] uppercase tracking-widest">No order history found</p>
            </div>
          ) : (
            orders.map(order => (
              <div key={order.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm animate-in fade-in slide-in-from-bottom-2">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">#{order.id}</span>
                    <p className="text-slate-900 font-black text-lg">{order.quantity} x {order.flavor}</p>
                  </div>
                  <div className={`px-2 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest ${
                    order.status === 'completed' ? 'bg-green-100 text-green-700' :
                    order.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {order.status}
                  </div>
                </div>
                <div className="flex justify-between items-center">
                   <p className="text-[10px] font-bold text-slate-400">{new Date(order.timestamp).toLocaleDateString()}</p>
                   <p className="text-[#e31b23] font-black">GHS {order.price.toFixed(2)}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 h-full flex flex-col justify-between bg-white overflow-y-auto no-scrollbar pt-safe pb-safe">
      <div className="space-y-6">
        <div className="flex justify-between items-center pt-8 px-1">
          <button 
            onClick={() => { hapticFeedback(5); onLogout(); }}
            className="w-14 h-14 bg-[#e31b23] rounded-2xl flex flex-col items-center justify-center text-white shadow-xl shadow-red-900/30 active:scale-90 transition-all z-10 cursor-pointer"
          >
            <span className="text-xl leading-none">🚪</span>
            <span className="text-[7px] font-black uppercase tracking-tighter mt-1">Exit</span>
          </button>
          <div className="flex-1 flex justify-center">
            <img src={BRAND_LOGO_URL} alt={BRAND_NAME} className="h-10 object-contain" />
          </div>
          <button 
            onClick={() => { hapticFeedback(5); setShowHistory(true); }}
            className="w-14 h-14 bg-slate-50 border-2 border-slate-100 rounded-2xl flex flex-col items-center justify-center shadow-sm active:scale-90 transition-all z-10"
          >
            <span className="text-xl leading-none">📜</span>
            <span className="text-[7px] font-black uppercase tracking-tighter mt-1 text-slate-400">List</span>
          </button>
        </div>

        <div className="bg-slate-50 p-4 rounded-3xl border border-slate-100 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Network Status</span>
            <span className="text-[11px] font-bold text-slate-800">{isUsingSms ? "📲 Offline SMS Mode" : "⚡ Real-time Live"}</span>
          </div>
          <button 
            onClick={() => { hapticFeedback(5); setForceSmsMode(!forceSmsMode); }}
            className={`px-4 py-2 rounded-full text-[9px] font-black uppercase transition-all shadow-sm ${forceSmsMode ? 'bg-[#e31b23] text-white' : 'bg-white text-slate-400 border border-slate-200'}`}
          >
            {forceSmsMode ? 'Bridge ON' : 'Switch to SMS'}
          </button>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-2xl">
           <button 
             onClick={() => { hapticFeedback(5); setOrderType('regular'); }}
             className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${orderType === 'regular' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}
           >Personal</button>
           <button 
             onClick={() => { hapticFeedback(5); setOrderType('bulk'); }}
             className={`flex-1 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${orderType === 'bulk' ? 'bg-[#e31b23] text-white shadow-lg' : 'text-slate-500'}`}
           >Bulk / Party</button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-[9px] font-black text-slate-400 mb-3 uppercase tracking-widest ml-1">Pick your Flavor</label>
            <div className="grid grid-cols-2 gap-3">
              {FLAVORS.map((f) => (
                <button
                  key={f.name}
                  onClick={() => { hapticFeedback(10); setFlavor(f.name); }}
                  className={`flex items-center gap-3 p-4 rounded-2xl border-2 transition-all active:scale-95 ${
                    flavor === f.name ? 'border-[#e31b23] bg-red-50 text-[#e31b23]' : 'border-slate-50 bg-slate-50 text-slate-600'
                  }`}
                >
                  <span className="text-2xl">{f.emoji}</span>
                  <span className="text-[11px] font-black uppercase tracking-wider">{f.name}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-[9px] font-black text-slate-400 mb-2 uppercase tracking-widest ml-1">Phone Number</label>
              <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl py-4 px-5 text-slate-900 font-bold focus:border-[#e31b23] focus:bg-white outline-none transition-all shadow-sm text-lg" />
            </div>
            <div>
              <label className="block text-[9px] font-black text-slate-400 mb-2 uppercase tracking-widest ml-1">Landmark (Location)</label>
              <input type="text" placeholder="e.g. Near Star Junction" value={landmark} onChange={(e) => setLandmark(e.target.value)} className="w-full bg-slate-50 border-2 border-slate-50 rounded-2xl py-4 px-5 text-slate-900 font-bold focus:border-[#e31b23] focus:bg-white outline-none transition-all shadow-sm text-lg" />
            </div>
          </div>
          <div className="pt-2">
            <label className="block text-[10px] font-black text-slate-400 mb-4 text-center uppercase tracking-widest">Select Quantity</label>
            <div className="flex items-center justify-between bg-slate-50 p-6 rounded-[2.5rem] border-2 border-slate-100 shadow-inner">
              <button onClick={() => adjustQty(-1)} className="w-16 h-16 rounded-3xl bg-white border border-slate-200 flex items-center justify-center text-4xl font-bold text-slate-300 active:scale-90 transition-transform shadow-sm">−</button>
              <div className="text-center flex flex-col items-center">
                <input type="number" value={quantity === 0 ? '' : quantity} onChange={(e) => { const val = parseInt(e.target.value); if (e.target.value === '') setQuantity(0); else if (!isNaN(val)) setQuantity(val); }} onBlur={() => { const min = orderType === 'bulk' ? MIN_BULK_QUANTITY : 1; if (quantity < min) setQuantity(min); }} className="w-32 bg-transparent text-6xl font-black text-slate-900 tabular-nums text-center focus:outline-none border-none p-0" />
                <p className="text-[12px] font-black text-[#e31b23] mt-2 tracking-widest uppercase">GHS {(quantity * currentPrice).toFixed(2)}</p>
              </div>
              <button onClick={() => adjustQty(1)} className="w-16 h-16 rounded-3xl bg-[#e31b23] flex items-center justify-center text-4xl font-bold text-white shadow-lg shadow-red-900/10 active:scale-90 transition-transform">+</button>
            </div>
          </div>
        </div>
      </div>
      <div className="space-y-4 pt-8">
        {status === 'success' && (
          <div className="bg-[#e31b23] text-white p-6 rounded-3xl text-center font-black shadow-2xl animate-in zoom-in-95 duration-300">
            {isUsingSms ? "📲 SEND THE SMS NOW!" : "✅ ORDER SUBMITTED!"}
          </div>
        )}
        <button onClick={handleRequest} disabled={loading || status === 'success'} className={`w-full py-6 rounded-3xl text-xl font-black shadow-2xl transition-all active:scale-[0.98] ${status === 'success' ? 'bg-slate-100 text-slate-400 cursor-default shadow-none' : 'bg-[#e31b23] text-white shadow-red-900/30'}`}>
          {loading ? <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto"></div> : status === 'success' ? "REQUESTED" : <span>{isUsingSms ? "Order via SMS 📲" : "Place Order Now ⚡"}</span>}
        </button>
      </div>
    </div>
  );
};

export default CustomerView;
