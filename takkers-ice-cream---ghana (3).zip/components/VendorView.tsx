
import React, { useState, useEffect } from 'react';
import { Order, Flavor, BRAND_NAME, BRAND_LOGO_URL } from '../types';
import { updateOrderStatus } from '../services/storageService';

interface Props {
  orders: Order[];
  onLogout: () => void;
  onRefresh: () => void;
}

const FLAVOR_EMOJIS: Record<Flavor, string> = {
  Vanilla: '🍦',
  Chocolate: '🍫',
  Strawberry: '🍓',
  Coconut: '🥥'
};

const VendorView: React.FC<Props> = ({ orders, onLogout, onRefresh }) => {
  const activeOrders = orders.filter(o => o.status === 'pending');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const hapticFeedback = (pattern: number | number[]) => {
    if ('vibrate' in navigator) navigator.vibrate(pattern);
  };

  // Vibrate when a new order arrives
  useEffect(() => {
    if (activeOrders.length > 0) {
      hapticFeedback([100, 50, 100]);
    }
  }, [activeOrders.length]);

  const handleComplete = (id: string) => {
    hapticFeedback(30);
    updateOrderStatus(id, 'completed');
    setSelectedOrder(null);
    onRefresh();
  };

  const handleCancel = (id: string) => {
    hapticFeedback([10, 100]);
    updateOrderStatus(id, 'cancelled');
    setSelectedOrder(null);
    onRefresh();
  };

  return (
    <div className="h-full flex flex-col bg-[#001a4d] overflow-hidden select-none pt-safe pb-safe">
      <div className="relative flex-1 bg-[#001a4d] overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/40"></div>
        
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[150%] aspect-square rounded-full border border-white/5 radar-ring"></div>
          <div className="w-[100%] aspect-square rounded-full border border-white/10 radar-ring" style={{ animationDelay: '0.6s' }}></div>
          <div className="w-[60%] aspect-square rounded-full border border-white/20 radar-ring" style={{ animationDelay: '1.2s' }}></div>
        </div>

        <div className="absolute top-0 inset-x-0 p-8 pt-12 flex flex-col items-center z-20">
          <img src={BRAND_LOGO_URL} alt={BRAND_NAME} className="h-12 mb-2 brightness-0 invert opacity-90" />
          <div className="bg-amber-500/10 border border-amber-500/20 px-4 py-1.5 rounded-full flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></div>
            <span className="text-[10px] font-black text-amber-400 uppercase tracking-[0.2em]">Local Radar Active</span>
          </div>
        </div>

        <div className="relative h-full pt-44 px-6 pb-6 flex flex-col gap-4 overflow-y-auto no-scrollbar z-10">
          <h2 className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em] mb-2 text-center">
            {activeOrders.length} Pending Pings
          </h2>

          {activeOrders.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 opacity-30">
              <div className="text-6xl">📡</div>
              <p className="text-white font-black text-[10px] uppercase tracking-widest">Scanning for requests...</p>
            </div>
          ) : (
            activeOrders.map((order) => (
              <button
                key={order.id}
                onClick={() => { hapticFeedback(10); setSelectedOrder(order); }}
                className="w-full bg-white/5 backdrop-blur-md border border-white/10 p-5 rounded-3xl flex items-center justify-between text-left active:scale-[0.98] transition-all group"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center text-2xl group-hover:bg-[#e31b23] transition-colors">
                    {FLAVOR_EMOJIS[order.flavor]}
                  </div>
                  <div>
                    <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">#{order.id}</span>
                    <p className="text-white font-black text-lg">{order.quantity} x {order.flavor}</p>
                    <p className="text-white/60 text-[11px] font-bold truncate max-w-[150px]">📍 {order.location.landmark}</p>
                  </div>
                </div>
                <div className="text-right">
                   <p className="text-[#e31b23] font-black text-lg">₵{order.price}</p>
                </div>
              </button>
            ))
          )}
        </div>

        {selectedOrder && (
          <div className="absolute inset-0 z-50 bg-[#001a4d]/95 backdrop-blur-xl p-8 pt-16 flex flex-col animate-in fade-in zoom-in-95 duration-300">
            <div className="flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-10">
                <button onClick={() => { hapticFeedback(5); setSelectedOrder(null); }} className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white text-xl">✕</button>
                <div className="text-right">
                  <span className="text-[#e31b23] font-black text-[10px] uppercase tracking-[0.2em]">Incoming Order</span>
                  <h3 className="text-white font-black text-3xl">#{selectedOrder.id}</h3>
                </div>
              </div>

              <div className="space-y-8">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5">
                    <p className="text-white/40 text-[9px] font-black uppercase tracking-widest mb-1">Customer</p>
                    <p className="text-white font-bold text-xl truncate">{selectedOrder.customerName}</p>
                    <p className="text-[#e31b23] font-black text-sm mt-1">{selectedOrder.customerPhone}</p>
                  </div>
                  <div className="bg-white/5 p-6 rounded-[2rem] border border-white/5 text-right">
                    <p className="text-white/40 text-[9px] font-black uppercase tracking-widest mb-1">Due Amount</p>
                    <p className="text-white font-bold text-3xl tabular-nums">₵{selectedOrder.price}</p>
                  </div>
                </div>

                <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 space-y-4">
                   <div className="flex items-center gap-4">
                     <div className="text-4xl">{FLAVOR_EMOJIS[selectedOrder.flavor]}</div>
                     <div>
                       <p className="text-white/40 text-[9px] font-black uppercase tracking-widest">Flavor</p>
                       <p className="text-white font-black text-2xl uppercase italic">{selectedOrder.flavor}</p>
                     </div>
                   </div>
                   <div className="h-px bg-white/5 w-full"></div>
                   <div>
                      <p className="text-white/40 text-[9px] font-black uppercase tracking-widest mb-2">Location</p>
                      <p className="text-white font-bold text-lg leading-tight">{selectedOrder.location.landmark}</p>
                      <button 
                        onClick={() => { hapticFeedback(5); window.open(`https://www.google.com/maps?q=${selectedOrder.location.lat},${selectedOrder.location.lng}`, '_blank'); }}
                        className="mt-4 w-full py-4 bg-white/10 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2"
                      >
                        🛰️ GPS Navigation
                      </button>
                   </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-6">
              <button onClick={() => handleCancel(selectedOrder.id)} className="py-5 rounded-3xl bg-white/5 text-white/40 font-black uppercase tracking-widest text-[10px] border border-white/5">Decline</button>
              <button onClick={() => handleComplete(selectedOrder.id)} className="py-5 rounded-3xl bg-[#e31b23] text-white font-black uppercase tracking-widest text-[10px] shadow-2xl shadow-red-900/50">Delivered</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VendorView;
