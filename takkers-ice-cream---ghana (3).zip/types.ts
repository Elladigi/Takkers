
export interface Location {
  lat: number;
  lng: number;
  address?: string;
  landmark?: string;
}

export type OrderType = 'regular' | 'bulk';
export type Flavor = 'Chocolate' | 'Strawberry' | 'Vanilla' | 'Coconut';

export interface Order {
  id: string;
  quantity: number;
  price: number;
  flavor: Flavor;
  location: Location;
  timestamp: number;
  status: 'pending' | 'completed' | 'cancelled';
  customerName?: string;
  customerPhone: string;
  isOffline?: boolean;
  orderType: OrderType;
  eventType?: 'Party' | 'School' | 'Program' | 'Other';
}

export type ViewType = 'customer' | 'vendor';

export const UNIT_PRICE = 5; // GHS 5
export const BULK_UNIT_PRICE = 4.5; // Slightly cheaper for bulk
export const MIN_BULK_QUANTITY = 20;
export const VENDOR_PHONE = "0541812917"; // Updated for Gibson Kofi
export const BRAND_NAME = "Takkers";

// Professional SVG Logo Data URI with updated text TAKKERS
export const BRAND_LOGO_URL = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 80"><text x="10" y="55" font-family="Arial, sans-serif" font-weight="900" font-size="42" fill="%23e31b23">TAKKERS</text><path d="M210 20 Q225 5 235 20 L222 55 Z" fill="%23e31b23"/><circle cx="222" cy="18" r="10" fill="%23facc15"/></svg>`;
