import { Order } from '../types';

const ORDERS_KEY = 'takkers_orders_v1';
const USER_PHONE_KEY = 'solo_user_phone';
const USER_NAME_KEY = 'solo_user_name';

export const getOrders = (): Order[] => {
  const data = localStorage.getItem(ORDERS_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
};

export const saveOrder = (order: Order): boolean => {
  try {
    const orders = getOrders();
    const updatedOrders = [order, ...orders];
    localStorage.setItem(ORDERS_KEY, JSON.stringify(updatedOrders));
    
    // Trigger a simple local notification if possible
    if (Notification.permission === 'granted') {
      new Notification('🍦 New Takkers Order!', {
        body: `Order #${order.id} for ${order.quantity} units.`,
      });
    }
    return true;
  } catch (e) {
    console.error("Local Save Error:", e);
    return false;
  }
};

export const updateOrderStatus = (id: string, status: Order['status']) => {
  const orders = getOrders();
  const updatedOrders = orders.map(o => o.id === id ? { ...o, status } : o);
  localStorage.setItem(ORDERS_KEY, JSON.stringify(updatedOrders));
};

export const getUserPhone = (): string | null => {
  return localStorage.getItem(USER_PHONE_KEY);
};

export const setUserPhone = (phone: string) => {
  localStorage.setItem(USER_PHONE_KEY, phone);
};

export const getUserName = (): string | null => {
  return localStorage.getItem(USER_NAME_KEY);
};

export const setUserName = (name: string) => {
  localStorage.setItem(USER_NAME_KEY, name);
};
