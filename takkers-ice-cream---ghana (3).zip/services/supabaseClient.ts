// Supabase backend disabled. Reverted to Local Storage + SMS Bridge.
export const supabase = null as any;
