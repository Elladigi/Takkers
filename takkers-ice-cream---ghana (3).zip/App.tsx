import React, { useState, useEffect } from 'react';
import { ViewType, Order, VENDOR_PHONE, BRAND_NAME, BRAND_LOGO_URL } from './types';
import CustomerView from './components/CustomerView';
import VendorView from './components/VendorView';
import { getOrders, saveOrder, getUserPhone, setUserPhone, getUserName, setUserName } from './services/storageService';

const App: React.FC = () => {
  const [view, setView] = useState<ViewType>('customer');
  const [orders, setOrders] = useState<Order[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [currentUserPhone, setCurrentUserPhone] = useState<string | null>(getUserPhone());
  const [currentUserName, setCurrentUserName] = useState<string | null>(getUserName());
  const [loginPhoneInput, setLoginPhoneInput] = useState('');
  const [loginNameInput, setLoginNameInput] = useState('');

  const refreshOrders = () => {
    const data = getOrders();
    setOrders(data);
  };

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    refreshOrders();

    const interval = setInterval(() => {
      refreshOrders();
    }, 5000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, []);

  const handleNewOrder = (order: Order) => {
    const success = saveOrder(order);
    if (success) {
      refreshOrders();
    }
  };

  const handleIdentify = () => {
    const cleanedPhone = loginPhoneInput.replace(/\D/g, '');
    const trimmedName = loginNameInput.trim();

    if (cleanedPhone.length >= 9 && trimmedName.length >= 2) {
      setUserPhone(cleanedPhone);
      setUserName(trimmedName);
      setCurrentUserPhone(cleanedPhone);
      setCurrentUserName(trimmedName);
    } else if (trimmedName.length < 2) {
      alert("Please enter your name.");
    } else {
      alert("Please enter a valid phone number.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('solo_user_phone');
    localStorage.removeItem('solo_user_name');
    setCurrentUserPhone(null);
    setCurrentUserName(null);
    setLoginPhoneInput('');
    setLoginNameInput('');
    setView('customer');
  };

  if (!currentUserPhone || !currentUserName) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-[#e31b23] p-6 animate-in fade-in duration-300">
        <div className="max-w-sm w-full bg-white rounded-[3rem] p-10 shadow-[0_30px_70px_rgba(0,0,0,0.5)] text-center space-y-8 border-b-8 border-black/10">
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-3xl shadow-xl border border-slate-50 flex items-center justify-center min-h-[100px]">
              <img src={BRAND_LOGO_URL} alt={BRAND_NAME} className="w-full max-w-[200px] object-contain" />
            </div>
            <div className="pt-2">
              <h1 className="text-slate-900 font-extrabold text-2xl tracking-tight">{BRAND_NAME} Delivery</h1>
              <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mt-1">Premium Ice Cream Service</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-3 text-left">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Your Name</label>
              <input 
                type="text" 
                placeholder="Samuel Osei"
                value={loginNameInput}
                onChange={(e) => setLoginNameInput(e.target.value)}
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-2 border-slate-100 font-bold focus:border-[#e31b23] outline-none transition-all text-lg"
              />
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Phone Number</label>
              <input 
                type="tel" 
                placeholder="054 XXX XXXX"
                value={loginPhoneInput}
                onChange={(e) => setLoginPhoneInput(e.target.value)}
                className="w-full px-6 py-4 rounded-2xl bg-slate-50 border-2 border-slate-100 font-bold focus:border-[#e31b23] outline-none transition-all text-lg"
              />
            </div>
            <button onClick={handleIdentify} className="w-full py-5 bg-[#e31b23] text-white rounded-2xl font-black shadow-lg shadow-red-900/40 active:scale-95 transition-all uppercase tracking-widest text-sm">
              Enter Store
            </button>
          </div>
        </div>
      </div>
    );
  }

  const isVendor = currentUserPhone === VENDOR_PHONE;

  return (
    <div className="h-screen w-full flex flex-col bg-[#001a4d] font-sans antialiased overflow-hidden">
      <div className="max-w-md w-full mx-auto h-full flex flex-col bg-white relative shadow-2xl">
        {!isOnline && (
          <div className="bg-[#e31b23] text-white text-[10px] py-2 text-center font-black uppercase tracking-[0.2em] z-[60] animate-pulse">
            ⚠️ OFFLINE BRIDGE ACTIVE
          </div>
        )}
        {isVendor && (
          <div className="absolute top-4 left-4 right-4 z-50 flex justify-end items-center pointer-events-none">
             <button 
               onClick={() => setView(view === 'customer' ? 'vendor' : 'customer')}
               className="pointer-events-auto bg-[#002366] text-white px-5 py-3 rounded-full text-[9px] font-black uppercase tracking-widest shadow-2xl active:scale-95 transition-all"
             >
               {view === 'customer' ? '📊 Management' : '🍦 Order Menu'}
             </button>
          </div>
        )}
        <main className="flex-1 relative h-full overflow-hidden">
          {view === 'customer' || !isVendor ? (
            <CustomerView 
              onOrderCreated={handleNewOrder} 
              isOnline={isOnline} 
              orders={orders}
              savedPhone={currentUserPhone}
              savedName={currentUserName}
              onLogout={handleLogout}
            />
          ) : (
            <VendorView orders={orders} onLogout={handleLogout} onRefresh={refreshOrders} />
          )}
        </main>
        <footer className="px-6 py-5 flex items-center justify-between bg-white border-t border-slate-100 z-[70] shadow-[0_-15px_40px_rgba(0,0,0,0.05)] pb-safe">
          <div className="text-left flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center text-lg shadow-inner">👤</div>
            <div className="max-w-[140px]">
              <p className="text-slate-400 text-[8px] font-black uppercase tracking-widest leading-none">Active User</p>
              <p className="text-[#001a4d] text-[12px] font-black truncate">{currentUserName}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="text-[10px] font-black text-[#e31b23] uppercase tracking-widest bg-red-50 hover:bg-[#e31b23] hover:text-white border border-red-100 px-6 py-4 rounded-xl active:scale-90 transition-all">
            Logout
          </button>
        </footer>
      </div>
    </div>
  );
};

export default App;